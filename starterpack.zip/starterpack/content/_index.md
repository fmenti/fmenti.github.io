---
layout: landing_page
image: avatar.jpg
---

Hi, I'm Carl! 👋

I am a Ph.D. student 🎓 in empirical barkology at Woof University where I work in the lab of Prof. Bark Twain 🏛
Most of my research is driven by trying to find an answer to the age-old question of *"Who is a good boy?"* &nbsp;🐶❓

In my free time, I like running 🐕💨, playing frisbee 🥏 and trying new foods! 🦴

Please feel free to get in touch! 📧